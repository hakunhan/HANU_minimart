const categories = [
  { id: "processors", name: "Processors" },
  { id: "memory", name: "Memory" },
  { id: "motherboards", name: "Motherboards" },
  { id: "video-cards", name: "Video Cards" },
  { id: "chassis", name: "Chassis" },
];

export default categories;
